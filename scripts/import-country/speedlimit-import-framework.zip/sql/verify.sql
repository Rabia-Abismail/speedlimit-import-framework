SELECT COUNT(*) FROM %SCHEMA%.roads;
SELECT indexname FROM pg_indexes WHERE schemaname='%SCHEMA%';
