#!/usr/bin/env bash
set -euo pipefail
COUNTRY="$1"
CONTINENT=$(grep "^$COUNTRY:" config/countries.yml|cut -d: -f2|xargs)
[ -z "$CONTINENT" ] && { echo "Unknown country"; exit 1; }

BASE=/opt/speedlimit
mkdir -p $BASE/osm/$COUNTRY
cd $BASE/osm/$COUNTRY

wget -N https://download.geofabrik.de/$CONTINENT/${COUNTRY}-latest.osm.pbf

sudo -u postgres psql osm <<SQL
CREATE SCHEMA IF NOT EXISTS $COUNTRY;
SQL

osm2pgsql --create --slim --output=flex  --style=$BASE/flex/roads.lua  --schema=$COUNTRY  --database=osm  $BASE/osm/$COUNTRY/${COUNTRY}-latest.osm.pbf

osm2pgsql-replication init  --database=osm  --schema=$COUNTRY  $BASE/osm/$COUNTRY/${COUNTRY}-latest.osm.pbf || true

echo "Import complete."
echo "Next:"
echo "1) Insert boundary into countries table"
echo "2) Run replication test"
echo "3) Run backup"
